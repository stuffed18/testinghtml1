window.__CONFIG__ = {
  // url must NOT end with a slash
  VITE_CORS_PROXY_URL: "https://tvwebapp.bookstuffing18.workers.dev/",
  VITE_TMDB_READ_API_KEY: "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0ZmVmZjQ1OTkyZThhMWI5NzdjMzY5ZDY3OTE5OGRiMSIsInN1YiI6IjY1MTNjOWM2YTE5OWE2MDBjNDliZTVkMiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.nq7Pur-V7ruAzejW5o28b8P1yzOfhZr5l1KIUDpGIo8"
};
